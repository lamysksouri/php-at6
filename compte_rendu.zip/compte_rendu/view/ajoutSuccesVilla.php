
Insertion effectuee avec succes 
<button><a href="../controller/listVilla.php" class="btn btn-primary btn-sm">Lister</a></button>
<form method="post" action="<?=$_SERVER['PHP_SELF']?>">
<div class="mb-3">
    <label class="form-label">Reference : </label>
    <input type="number" class="form-control" id="recherche"  name="recherche">
  </div>
  <input type="submit" class="btn btn-primary" name="ok" value="Chercher">
</form>
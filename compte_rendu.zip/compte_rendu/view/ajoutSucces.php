
Insertion effectuee avec succes 
<button><a href="../controller/listAppartement.php" class="btn btn-primary btn-sm">Lister</a></button>